package cts.ivan.cristina.g1081.pattern.factory;

public enum TipVideoclip { ClipLive,Tutorial
}
